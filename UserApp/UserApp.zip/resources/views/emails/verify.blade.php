<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify</title>
</head>
<body>
    <h1>Verify Your Email Address</h1>
    <p> {{ $otp  }} </p>
    <p>If you did not requested an OTP, then please ignore this mail</p>
    <p>Thanks</p>
</body>
</html>